// ─────────────────────────────────────────────────────────────────────────────
// SINGLE SOURCE OF CONTENT
// Edit this file to drop in your exact, verified company copy, contact details,
// management names, and gallery images. Every page reads from here.
// ─────────────────────────────────────────────────────────────────────────────

export const company = {
  name: 'Assurance Moni Group',
  tagline: 'Excellence in Garments, Real Estate, and Beyond.',
  shortDescription:
    "Driving Bangladesh's export industry forward. From ready-made garments to printing, packages, and real estate development, Assurance Moni Group delivers uncompromising quality.",
  established: '— add year —',
  email: 'info@assurancemonigroup.com',
  phone: '+880 — add number —',
  address: 'Dhaka, Bangladesh',
}

export const about = {
  heading: 'About Us',
  lead:
    'Assurance Moni Group is a diversified Bangladeshi conglomerate built on a single conviction: that quality, delivered consistently, compounds into trust.',
  paragraphs: [
    'What began as a ready-made garments export operation has grown into a multi-industry group spanning garment manufacturing, commercial printing and packaging, and real estate development. Each concern operates with the same discipline — rigorous standards, dependable delivery, and long-term relationships with partners at home and abroad.',
    'Our garments division serves international buyers with compliant, on-time production at scale. Our printing and packages division supplies the materials that move products to market. Our real estate division shapes spaces where people live and work. Together they form a group that is greater than the sum of its parts.',
    'We measure ourselves not by how much we produce, but by how reliably we keep our word — to buyers, to employees, and to the communities we operate in.',
  ],
  stats: [
    { value: '3', label: 'Core industries' },
    { value: '100%', label: 'Export-oriented RMG' },
    { value: 'Dhaka', label: 'Headquarters' },
  ],
}

export const chairman = {
  heading: 'Profile of the Chairman',
  name: '— Chairman name —',
  title: 'Chairman & Managing Director',
  // Replace with a real, verified portrait of the chairman.
  photo: '',
  message: [
    'It gives me great pleasure to welcome you to Assurance Moni Group. Over the years our group has grown from a single garments export venture into a diversified house with interests across manufacturing, packaging, and property.',
    'Our success rests on a simple philosophy: deliver quality without compromise, honour every commitment, and invest in the people who make it possible. These principles have guided every decision and every expansion we have undertaken.',
    'As we look ahead, we remain committed to contributing to the growth of Bangladesh\u2019s export economy while creating lasting value for our partners, our employees, and the nation. I invite you to explore what we do and to build with us.',
  ],
}

export type Manager = {
  name: string
  role: string
  photo: string
}

export const management: Manager[] = [
  {
    name: 'Amzad Hossain',
    role: 'Executive Director',
    photo: '/executive-amzad-hossain.webp',
  },
  {
    name: '— add name —',
    role: 'Director, Operations',
    photo: '',
  },
  {
    name: '— add name —',
    role: 'Director, Finance',
    photo: '',
  },
  {
    name: '— add name —',
    role: 'Director, Marketing',
    photo: '',
  },
]

export type Concern = {
  slug: string
  name: string
  summary: string
  body: string[]
  highlights: string[]
}

export const concerns: Concern[] = [
  {
    slug: 'ready-made-garments',
    name: 'Ready Made Garments',
    summary:
      'Export-oriented apparel manufacturing built for international buyers who demand compliance, consistency, and on-time delivery.',
    body: [
      'Our flagship division produces ready-made garments for export markets, operating to international compliance standards across woven and knit product lines. From sampling to bulk shipment, we manage the full production cycle in-house.',
      'A skilled workforce, modern machinery, and disciplined quality control allow us to meet the volume and precision that global brands require — order after order, season after season.',
    ],
    highlights: [
      'Woven & knit production',
      'Compliance-driven facilities',
      'Reliable lead times',
      'Full-cycle sampling to shipment',
    ],
  },
  {
    slug: 'printing-packages',
    name: 'Printing & Packages',
    summary:
      'Commercial printing and packaging solutions that protect, present, and move products to market.',
    body: [
      'Our printing and packages division supplies cartons, labels, tags, and packaging materials to manufacturers and exporters. Precise colour, durable construction, and dependable supply make us a trusted partner across the supply chain.',
      'By keeping packaging in-house alongside our garments operation, we shorten lead times and hold a single standard of quality from product to package.',
    ],
    highlights: [
      'Cartons & corrugated packaging',
      'Labels, tags & trims',
      'Consistent colour fidelity',
      'Integrated supply for exporters',
    ],
  },
  {
    slug: 'real-estate',
    name: 'Real Estate',
    summary:
      'Thoughtful residential and commercial development that creates lasting spaces to live and work.',
    body: [
      'Our real estate division develops and manages residential and commercial properties, applying the same standards of quality and reliability that define the rest of the group.',
      'We focus on durable construction, considered design, and locations that hold their value — building places that communities are proud to call home and businesses are confident to operate from.',
    ],
    highlights: [
      'Residential development',
      'Commercial properties',
      'Quality construction',
      'Long-term value',
    ],
  },
]

// Gallery placeholders. Replace `src` values with your own images placed in /public,
// e.g. '/gallery/factory-floor.jpg'. Captions are optional.
export type GalleryItem = { src: string; caption: string }

export const gallery: GalleryItem[] = [
  { src: '', caption: 'Production floor' },
  { src: '', caption: 'Quality control' },
  { src: '', caption: 'Packaging line' },
  { src: '', caption: 'Corporate office' },
  { src: '', caption: 'Real estate project' },
  { src: '', caption: 'Warehouse & logistics' },
  { src: '', caption: 'Team at work' },
  { src: '', caption: 'Finished goods' },
]

export const careers = {
  heading: 'Career',
  lead:
    'We grow by investing in people. If you are driven, dependable, and ready to build, we would like to hear from you.',
  note: 'Send your CV to the email below with the position you are interested in.',
}

export const navLinks = [
  { label: 'Home', to: '/' },
  { label: 'About Us', to: '/about' },
  { label: 'Corporate Management', to: '/corporate-management' },
  { label: 'Our Concerns', to: '/concerns' },
  { label: 'Gallery', to: '/gallery' },
  { label: 'Contact', to: '/contact' },
]

export const heroVideoUrl =
  'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260328_083109_283f3553-e28f-428b-a723-d639c617eb2b.mp4'
